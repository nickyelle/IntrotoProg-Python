#-------------------------------------------------#
# Title: Assignment 6
# Dev:   NDietrich
# Date:  August 19, 2018
# ChangeLog - (Who, When, What):
#-------------------------------------------------#
#Define data and variables----------------------------
AssignmentFile = "C:\_PythonClass\ToDo.txt"
#the task and priority are string vars that will be loaded into my dictionary
strData = ""
Task = None #using none for task and priority to signify that this is currently empty (but will be used as program progresses)
Priority = None
ToDoDic = {} #dictionary of my To Do items - acts as a table of rows
ToDoTblData = []

# Program Processing ----------------------------
#Task 1 - load the existing text file
# This contains methods used to process my to do list
class ProcessToDo():
    @staticmethod
    def LoadToDoFile():
        objFile=open(AssignmentFile, "r")
        for line in objFile:
            strData = line.split(",")  # readline() reads a line of the data into 2 elements
            ToDoDic = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
            ToDoTblData.append(ToDoDic)
        objFile.close()
    @staticmethod
    def ShowToDoData():
        return print(ToDoTblData)

    @staticmethod
    def AddToDoTask():
        Task = str(input("Please enter a new to-do task: "))
        Priority = str(input("Indicate the task priority (low | medium | high): "))
        ToDoDic = {"Task": Task, "Priority": Priority +" \n"}
        ToDoTblData.append(ToDoDic)

    @staticmethod
    def RemoveToDoTask():
        strKeyToRemove = input("Which Task Would You Like to Remove?: ")
        blnItemRemoved = False  # Creating a boolean Flag
        intRowNumber = 0
        while (intRowNumber < len(ToDoTblData)):
            # the values function creates a list!
            if (strKeyToRemove == str(list(dict(ToDoTblData[intRowNumber]).values())[0])):
                del ToDoTblData[intRowNumber]
                blnItemRemoved = True
            # end if
            intRowNumber += 1
        if blnItemRemoved == True:
            print("The task was removed.")
        else:
            print("I'm sorry, but I could not find that task.")

    @staticmethod
    def SaveToDo():
        objFile = open(AssignmentFile, "w")
        for ToDoDic in ToDoTblData:
            objFile.write(ToDoDic["Task"] + "," + ToDoDic["Priority"] + "\n")
        objFile.close()

#Input Output section
ProcessToDo.LoadToDoFile()
while(True):
    print("""
       Menu of Options
       1) Show current data
       2) Add a new item.
       3) Remove an existing item.
       4) Save Data to File
       5) Exit Program
       """)
    strChoice = str(input("Which option would you like to perform? Input [1 to 5] - "))
    print()  # adding a new line
    if(strChoice == '1'): #show current menu
        ProcessToDo.ShowToDoData()
        continue
    elif(strChoice == '2'): # inserts new task into to do
        ProcessToDo.AddToDoTask()
        continue
    elif(strChoice == '3'): # removes and item from the to do list
        ProcessToDo.ShowToDoData()
        ProcessToDo.RemoveToDoTask()
        continue
    elif(strChoice == '4'): #saves my file
        ProcessToDo.SaveToDo()
        continue
    elif(strChoice == '5'):#EXIT!
        break

