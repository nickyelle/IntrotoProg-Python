#-------------------------------------------------#
# Title: Assignment 5
# Dev:   NDietrich
# Date:  August 14, 2018
# Desc:  Create a to-do list which allows the user the choice to add, remove, and save to a Dictionary file
# ChangeLog - (Who, When, What):
#-------------------------------------------------#

# declare variables and constants
AssignmentFile = "C:\_PythonClass\Todo.txt"
strData = ""
Task = str
Priority = str
#CREATE THE DICTIONARY
ToDoDic = {}

# Step 1 - Load data from a file
objFile = open(AssignmentFile,'r')
for line in objFile:
    (Task, Priority)=line.split(",")
    # assign the task and priority relationship to dictionary and assign to table
    ToDoDic[Task.strip()] = Priority.strip()

# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()#adding a new line

    # Step 3 -Show the current items in the table and add header with current to-do
    if (strChoice.strip() == '1'):
        print(str("Current items in you to-do list:"))
        print(ToDoDic)
        continue

    # Step 4 - Add a new task and priority to the current to-do list and show use list with new task and priority added
    elif(strChoice.strip() == '2'):
        NewTask = input("Please enter a new task: ")
        NewPriority=input("Please enter priority of the new task (low, medium, high): ")
        ToDoDic[NewTask]=NewPriority
        print(ToDoDic)
        continue

    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        print(ToDoDic)  # show user current to-do list
        RemoveToDo=input("What is the to-do list task would you like to remove? ")
        del ToDoDic[RemoveToDo]
        print("Confirming that", RemoveToDo,"has been removed from your current to-do list.")
        continue

    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        SaveToDo=input("Save the to-do list? (y / n): ").lower()
        if(SaveToDo=='y'):
             objFile = open(AssignmentFile, 'w')
        for i in ToDoDic:
            objFile.write(i + "," + ToDoDic[i] + "\n")
        objFile.close()
        print ("confirming your list has been saved")
        continue

    # Step 7 - Exit program
    elif (strChoice == '5'):
        print("closing program...")
        break
